📸 Instagramy - Flutter UI Project
A pixel-perfect clone of the Instagram UI built during the final competition of the Flutter Bootcamp.
This project focuses on creating a clean, scalable, and responsive social media interface using Flutter.

📸 Demo

🚀 Features
Dynamic Stories Bar: A horizontal scrolling list (ListView.builder) for user stories with custom avatars.

Interactive Feed: A vertical feed displaying posts with user info, images, and engagement actions (Like, Comment, Share, Bookmark).

Responsive Design: Built using flexible widgets to ensure it looks great on different screen sizes.

Iconly Integration: Utilizes the Iconly package for high-quality, modern icons.

Logic-Ready UI: Includes conditional rendering (e.g., heart icon color toggling based on index).

🛠️ Tech Stack
Framework: Flutter

Language: Dart

Icons: Iconly

Architecture: Clean UI separation using StatelessWidgets and data-driven rendering.

🏗️ Technical Highlights
In this project, I implemented several key Flutter concepts:

Nested Scroll Views: Managing a horizontal list (Stories) inside a vertical scrollable body.

ShrinkWrap & Physics: Using shrinkWrap: true and NeverScrollableScrollPhysics() to integrate a ListView inside a SingleChildScrollView.

List Mapping: Dynamically generating UI components from a List of Maps to simulate real-world data handling.

