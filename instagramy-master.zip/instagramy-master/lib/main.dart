import 'package:flutter/material.dart';
import 'package:instagramy/instagramy_screen.dart';

void main() {
  runApp(const InstagramyApp());
}

class InstagramyApp extends StatelessWidget {
  const InstagramyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Instagramy App',
      home: InstagramyScreen(),
    );
  }
}
