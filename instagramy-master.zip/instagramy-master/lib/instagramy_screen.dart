import 'package:flutter/material.dart';
import 'package:iconly/iconly.dart';

class InstagramyScreen extends StatelessWidget {
  InstagramyScreen({super.key});

  List stories = [
    {"image": "assets/stories/google.png", "title": "your Story"},
    {"image": "assets/stories/youtube.png", "title": "Youtube"},
    {"image": "assets/stories/facebook.png", "title": "Facebook"},
    {"image": "assets/stories/linkedin.png", "title": "Linkedin"},
    {"image": "assets/stories/github.png", "title": "Github"},
  ];
  List posts = [
    {
      "profileImage": "assets/posts/Astro.jpg",
      "postImage": "assets/posts/Astro.jpg",
      "title": "Astro",
      "subtitle": "GDGoC Benha Astro",
      "likes": "7.5 K",
      "comments": "150",
    },
    {
      "profileImage": "assets/posts/backend.jpg",
      "postImage": "assets/posts/backend.jpg",
      "title": "Backend",
      "subtitle": "GDGoC Benha Backend",
      "likes": "7.5 K",
      "comments": "150",
    },
    {
      "profileImage": "assets/posts/cyber.jpg",
      "postImage": "assets/posts/cyber.jpg",
      "title": "Cyber",
      "subtitle": "GDGoC Benha Cyber",
      "likes": "7.5 K",
      "comments": "150",
    },
    {
      "profileImage": "assets/posts/data_science.jpg",
      "postImage": "assets/posts/data_science.jpg",
      "title": "Data Science",
      "subtitle": "GDGoC Benha Data Science",
      "likes": "7.5 K",
      "comments": "150",
    },
    {
      "profileImage": "assets/posts/flutter.jpg",
      "postImage": "assets/posts/flutter.jpg",
      "title": "Flutter",
      "subtitle": "GDGoC Benha Flutter",
      "likes": "7.5 K",
      "comments": "150",
    },
    {
      "profileImage": "assets/posts/front_end.jpg",
      "postImage": "assets/posts/front_end.jpg",
      "title": "FrontEnd",
      "subtitle": "GDGoC Benha FrontEnd",
      "likes": "7.5 K",
      "comments": "150",
    },
    {
      "profileImage": "assets/posts/ocp.jpg",
      "postImage": "assets/posts/ocp.jpg",
      "title": "Ocp",
      "subtitle": "GDGoC Benha Ocp",
      "likes": "7.5 K",
      "comments": "150",
    },
    {
      "profileImage": "assets/posts/ui_ux.jpg",
      "postImage": "assets/posts/ui_ux.jpg",
      "title": "Ui Ux",
      "subtitle": "GDGoC Benha Ui Ux",
      "likes": "7.5 K",
      "comments": "150",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Instagramy",
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
        ),
        actions: const [
          Icon(IconlyLight.profile),
          SizedBox(width: 20),
          Icon(IconlyLight.notification),
          SizedBox(width: 15),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 15),
        children: [
          const SizedBox(height: 10),
          const Text(
            "Stories",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
          ),
          const SizedBox(height: 10),

          // Horizontal Stories Section
          SizedBox(
            height: 110,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: stories.length,
              itemBuilder: (context, index) {
                final story = stories[index];
                return Padding(
                  padding: const EdgeInsets.only(right: 15),
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 32,
                        backgroundColor: Colors.pink,
                        child: CircleAvatar(
                          radius: 30,
                          backgroundImage: AssetImage(story["image"]),
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        story["title"],
                        style: const TextStyle(fontSize: 12),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          // Posts Section
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: posts.length,
            itemBuilder: (context, index) {
              final post = posts[index];
              return Column(
                children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      backgroundImage: AssetImage(post["profileImage"]),
                    ),
                    title: Text(
                      post["title"],
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(post["subtitle"]),
                    trailing: const Icon(IconlyLight.more_circle),
                  ),

                  // Post Image with ClipRRect for rounded corners
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(
                      post["postImage"],
                      height: 350,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),

                  const SizedBox(height: 12),

                  // Interaction Row
                  Row(
                    children: [
                      Icon(
                        IconlyBold.heart,
                        color: index % 2 == 0 ? Colors.red : Colors.grey,
                      ),
                      const SizedBox(width: 5),
                      Text(post["likes"]),
                      const SizedBox(width: 15),
                      const Icon(IconlyLight.chat),
                      const SizedBox(width: 5),
                      Text(post["comments"]),
                      const SizedBox(width: 15),
                      const Icon(IconlyLight.send),
                      const SizedBox(width: 185),
                      const Icon(IconlyLight.bookmark),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      color: Colors.grey.shade300,
                      width: double.infinity,
                      height: 2,
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}
